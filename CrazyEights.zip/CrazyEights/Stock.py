import pygame

class Stock: #just show what you can add
    def __init__ (self, posRatio, sizeRatio, startingCard, app):
        self.cardsInStock = [startingCard]
        self.image = startingCard.image
        self.posRatio = posRatio
        self.sizeRatio = sizeRatio
        self.app = app

    def addCardToStock(self,cardToAdd):
        self.cardsInStock.append(cardToAdd)
        self.image = cardToAdd.image

    def process(self, surfaceToDraw):
        pos = (self.app.width * self.posRatio[0], self.app.height * self.posRatio[1])
        self.image = pygame.transform.smoothscale(self.image,(self.sizeRatio[0] * self.app.width, self.sizeRatio[1] * self.app.height))
        surfaceToDraw.blit(self.image,pos)

    def getCard(self):
        return self.cardsInStock[-1]
    
    def __str__(self):
        return "this is stock"