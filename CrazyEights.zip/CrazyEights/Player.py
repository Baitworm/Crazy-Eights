import pygame,math
class Player:
    def __init__(self, points, rotation, posRatio, app):
        self.points = points
        self.posRatio = posRatio
        self.rotation = rotation
        self.app = app
        self.hand = []

    def addToHand(self,toAdd):
        self.hand.append(toAdd)

    def process(self, surfaceToDraw):
        mousePos = pygame.mouse.get_pos()
        spacing = self.app.cardSize[0] * self.app.width / len(self.hand)
        x = self.app.width * self.posRatio[0]
        y = self.app.height * self.posRatio[1]
        for i in range(math.floor(len(self.hand)/-2),math.floor(len(self.hand)/2)):
            card = self.hand[i + math.floor(len(self.hand)/2)]
            sizedImage = pygame.transform.smoothscale(card.image,(self.app.cardSize[0] * self.app.width, self.app.cardSize[1] * self.app.height))
            rotatedImage = pygame.transform.rotate(sizedImage,self.rotation)
            
            
            if self.rotation % 180 == 0:
                x = self.app.width * self.posRatio[0] + spacing * i
            else:
                y = self.app.height * self.posRatio[1] + spacing * i

            if self.hovering(mousePos, (x,y), spacing) and y > self.app.height * self.posRatio[1] - 150 :
                surfaceToDraw.blit(rotatedImage,(x, y - 10))
            else:
                surfaceToDraw.blit(rotatedImage,(x, y))
        
    def hovering(self, mousePos, areaPos, spacing):
        if self.__str__().__eq__("I am AI"):
            return False
        if self.rotation % 180 == 0:    
            return areaPos[0] <= mousePos[0] <= areaPos[0] + spacing
    


class Ai(Player):
    def __init__(self, points, rotation, posRatio, app):
        super().__init__(points, rotation, posRatio, app)

    def addToHand(self, toAdd):
        toAdd.image = pygame.image.load("Cover.jpg").convert()
        super().addToHand(toAdd)
    
    def __str__(self):
        return "I am AI"