import pygame,math
class Player:
    def __init__(self, points, rotation, posRatio, app):
        self.points = points
        self.posRatio = posRatio
        self.rotation = rotation
        self.app = app
        self.hand = []

    def addToHand(self,toAdd):
        self.hand.append(toAdd)

    def process(self, surfaceToDraw):
        spacing = self.app.cardSize[0] * self.app.width / len(self.hand)
        x = self.app.width * self.posRatio[0]
        y = self.app.height * self.posRatio[1]
        for i in range(math.floor(len(self.hand)/-2),math.floor(len(self.hand)/2)):
            sizedImage = pygame.transform.smoothscale(self.hand[i + math.floor(len(self.hand)/2)].image,(self.app.cardSize[0] * self.app.width, self.app.cardSize[1] * self.app.height))
            rotatedImage = pygame.transform.rotate(sizedImage,self.rotation)
            
            
            if self.rotation % 180 == 0:
                x = self.app.width * self.posRatio[0] + spacing * i
            else:
                y = self.app.height * self.posRatio[1] + spacing * i
            surfaceToDraw.blit(rotatedImage,(x, y))
            
    


class Ai(Player):
    def __init__(self, points, rotation, posRatio, app):
        super().__init__(points, rotation, posRatio, app)

    def addToHand(self, toAdd):
        toAdd.image = pygame.image.load("Cover.jpg").convert()
        super().addToHand(toAdd)