import pygame
class Player:
    def __init__(self, points, rotation, posRatio, app):
        self.points = points
        self.posRatio = posRatio
        self.rotation = rotation
        self.app = app
        self.hand = []

    def addToHand(self,toAdd):
        self.hand.append(toAdd)

    def process(self, surfaceToDraw):
        x = self.app.width * self.posRatio[0]
        y = self.app.height * self.posRatio[1]
        spacing = 121/len(self.hand)

        for card in self.hand:
            sizedImage = pygame.transform.smoothscale(card.image,(self.app.cardSize[0] * self.app.width, self.app.cardSize[1] * self.app.height))
            rotatedImage = pygame.transform.rotate(sizedImage,self.rotation)
            
            surfaceToDraw.blit(rotatedImage,(x, y))
            x += spacing
    


class Ai(Player):
    def __init__(self, points, rotation, posRatio, app):
        super().__init__(points, rotation, posRatio, app)

    def addToHand(self, toAdd):
        toAdd.image = pygame.image.load("Cover.jpg").convert()
        super().addToHand(toAdd)