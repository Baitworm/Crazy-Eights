import Main,pygame

class Button(object): #https://thepythoncode.com/article/make-a-button-using-pygame-in-python
    
    def __init__(self, pos, text, outlineSize, font, app):
        self.pos = pos
        self.text = text
        self.outlineSize = outlineSize
        self.font = font.render(text,False,Main.WHITE,Main.BLACK)
        self.debounce = pygame.time.get_ticks()
        self.app = app

    def process(self,surfaceToDraw):
        surfaceToDraw.blit(self.font,self.pos)
        pygame.draw.rect(surfaceToDraw,Main.WHITE,pygame.rect.Rect(self.pos[0] - 5, self.pos[1] - 5, self.font.get_size()[0] + 15, self.font.get_size()[1] + 15), self.outlineSize)
        mousePos = pygame.mouse.get_pos()
        if self.checkInBounds(mousePos,self.pos,self.font.get_size()):
            if pygame.mouse.get_pressed(num_buttons=3)[0] and pygame.time.get_ticks() - self.debounce >= 100:
                self.debounce = pygame.time.get_ticks()
                self.on_press()
    def on_press(self):
        pass
    
    def checkInBounds(self,containedPos,containerPos,containerSize):
        return containerPos[0] <= containedPos[0] <= (containerPos[0] + containerSize[0]) and containerPos[1] <= containedPos[1] <= (containerPos[1] + containerSize[1])
    
class CreditsButton(Button):
    
    def __init__(self, pos, text, outlineSize, font, app):
        super().__init__(pos, text, outlineSize, font, app)

    def on_press(self):
       self.app.gameState = 0
        
class BackButton(Button):
    def __init__(self, pos, text, outlineSize, font, app):
        super().__init__(pos, text, outlineSize, font, app)

    def on_press(self):
        self.app.gameState = 1

class PureText(Button):
    def __init__(self, pos, text, outlineSize, font, app):
        super().__init__(pos, text, outlineSize, font, app)
    
class StartButton(Button):
    def __init__(self, pos, text, outlineSize, font, app):
        super().__init__(pos, text, outlineSize, font, app)
        
    def on_press(self):
        self.app.gameState = 2