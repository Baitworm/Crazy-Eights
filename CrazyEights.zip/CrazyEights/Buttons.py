import pygame
import math

class Button: #https://thepythoncode.com/article/make-a-button-using-pygame-in-python
    
    def __init__(self, posRatio, sizeRatio, app):
        self.posRatio = posRatio
        self.sizeRatio = sizeRatio
        self.debounce = pygame.time.get_ticks()
        self.app = app
        self.beingPressed = False

    def process(self,surfaceToDraw):
        pass

    def on_press(self):
        pass
    
    def checkInBounds(self,containedPos,containerPos,containerSize):
        return containerPos[0] <= containedPos[0] <= (containerPos[0] + containerSize[0]) and containerPos[1] <= containedPos[1] <= (containerPos[1] + containerSize[1])
    
class TextButton(Button):

    def __init__(self, posRatio, sizeRatio, text, outlineSize, fontName, app):
        super().__init__(posRatio, sizeRatio, app)
        self.text = text
        self.outlineSize = outlineSize
        self.fontName = fontName
        self.font = pygame.font.SysFont(self.fontName, self.app.width // 25)
    
    def process(self, surfaceToDraw):
        self.font = pygame.font.SysFont(self.fontName, math.floor(self.sizeRatio * self.app.width))
        fontRender = self.font.render(self.text,False,(255,255,255),(0,0,0))
        pos = (self.posRatio[0] * self.app.width, self.posRatio[1] * self.app.height)
        surfaceToDraw.blit(fontRender,pos)
        pygame.draw.rect(surfaceToDraw,(255,255,255),pygame.rect.Rect(pos[0] - 5, pos[1] - 5, fontRender.get_size()[0] + 15, fontRender.get_size()[1] + 15), self.outlineSize)

        mousePos = pygame.mouse.get_pos()
        if self.checkInBounds(mousePos, pos, fontRender.get_size()):
            if pygame.mouse.get_pressed(num_buttons=3)[0] and not self.beingPressed:
                self.beingPressed = True
                if pygame.time.get_ticks() - self.debounce >= 100:
                    self.debounce = pygame.time.get_ticks()
                    self.on_press()
            else:
                if not pygame.mouse.get_pressed(num_buttons=3)[0]:
                    self.beingPressed = False

class CreditsButton(TextButton):
    
    def __init__(self, pos, sizeRatio, text, outlineSize, font, app):
        super().__init__(pos, sizeRatio, text, outlineSize, font, app)

    def on_press(self):
       self.app.gameState = 0
        
class BackButton(TextButton):
    def __init__(self, pos, sizeRatio, text, outlineSize, font, app):
        super().__init__(pos, sizeRatio, text, outlineSize, font, app)

    def on_press(self):
        self.app.gameState = 1

class PureText(TextButton):
    def __init__(self, pos, sizeRatio, text, outlineSize, font, app):
        super().__init__(pos, sizeRatio, text, outlineSize, font, app)
    
class StartButton(TextButton):
    def __init__(self, pos, sizeRatio, text, outlineSize, font, app):
        super().__init__(pos, sizeRatio, text, outlineSize, font, app)

    def on_press(self):
        self.app.gameState = 2

class Deck(Button):
    def __init__(self, posRatio, sizeRatio, cardsGiven, app):
        super().__init__(posRatio, sizeRatio, app)
        self.image = pygame.image.load("Cover.jpg").convert()
        self.cardsInDeck = cardsGiven

    def process(self, surfaceToDraw):
        pos = (self.app.width * self.posRatio[0], self.app.height * self.posRatio[1])
        scaledImage = pygame.transform.smoothscale(self.image,(self.sizeRatio[0] * self.app.width, self.sizeRatio[1] * self.app.height))
        surfaceToDraw.blit(scaledImage,pos)
        mousePos = pygame.mouse.get_pos()
        if self.checkInBounds(mousePos, pos, scaledImage.get_size()):
            if pygame.mouse.get_pressed(num_buttons=3)[0] and not self.beingPressed:
                self.beingPressed = True
                if pygame.time.get_ticks() - self.debounce >= 100:
                    self.debounce = pygame.time.get_ticks()
                    self.on_press()
            else:
                if not pygame.mouse.get_pressed(num_buttons=3)[0]:
                    self.beingPressed = False

    def on_press(self):
        # add card to player from deck
        self.app.currentScreen.players[0].addToHand(self.cardsInDeck.pop())

    def getCards(self):
        return self.cardsInDeck
