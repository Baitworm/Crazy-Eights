import Main, Buttons

class Screen(object):

    def __init__(self, name, font,app):
        self.name = name
        self.buttons = []
        self.font = font
        self.app = app
    
    def addButton(self, type, pos):
        pass

class TitleScreen(Screen):

    def __init__(self, name, font, app):
        super().__init__(name,font, app)

    def addButton(self, type, pos):
        btn = Buttons.PureText(pos, "Crazy Eights", 3, self.font, self.app)
        if type == 'Credits':
            btn = Buttons.CreditsButton(pos,"Credits",3,self.font, self.app)
        else:
            if type == 'Start':
                btn = Buttons.StartButton(pos,type, 3, self.font, self.app)
        self.buttons.append(btn)
        
        
class CreditsScreen(Screen):
    def __init__(self, name, font, app):
        super().__init__(name,font, app)

    def addButton(self, type, pos):
        btn = Buttons.PureText(pos,type,1, self.font, self.app)

        if type == 'Back':
            btn = Buttons.BackButton(pos, "←", 1, self.font, self.app)
                
        self.buttons.append(btn)

class PlayingScreen(Screen):
    def __init__(self, name, font, app):
        super().__init__(name,font, app)
    