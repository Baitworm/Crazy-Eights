import pygame
from Player import Player,Ai
from Buttons import PureText,CreditsButton,StartButton,BackButton
class Screen(object):

    def __init__(self, name,fontName ,app):
        self.name = name
        self.buttons = []
        self.fontName = fontName
        self.app = app
        self.font = pygame.font.SysFont(self.fontName,25)
    
    def addButton(self, type, posRatios, sizeRatios):
        pass

class TitleScreen(Screen):

    def __init__(self, name, font, app):
        super().__init__(name,font, app)

    def addButton(self, type, posRatios, sizeRatios):
        btn = PureText(posRatios, sizeRatios, "Crazy Eights", 3, self.fontName, self.app)
        if type == 'Credits':
            btn = CreditsButton(posRatios, sizeRatios,"Credits",3,self.fontName, self.app)
        else:
            if type == 'Start':
                btn = StartButton(posRatios, sizeRatios,type, 3, self.fontName, self.app)
        self.buttons.append(btn)
        
        
class CreditsScreen(Screen):
    def __init__(self, name, font, app):
        super().__init__(name,font, app)

    def addButton(self, type, pos, sizeRatios):
        btn = PureText(pos, sizeRatios, type, 1, self.fontName, self.app)

        if type == 'Back':
            btn = BackButton(pos, sizeRatios, "←", 1, self.fontName, self.app)
                
        self.buttons.append(btn)

class PlayingScreen(Screen):
    def __init__(self, name, font, app):
        super().__init__(name, font, app)
        self.players = []

    def addToScreen(self,whatToAdd):
        self.buttons.append(whatToAdd)

    def addPlayer(self, pos, amountPts, rotation): # figure out positions later
        self.players.append(Player(amountPts, rotation, pos, self.app))
        self.buttons.append(self.players[-1])

    def addAI(self,pos,amountPts, rotation):
        self.players.append(Ai(amountPts, rotation, pos, self.app))
        
    def getPlayers(self):
        return self.players
        
    