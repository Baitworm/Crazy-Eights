import pygame
import random
from Buttons import Deck
from Card import Card
from Stock import Stock
from Screens import CreditsScreen, TitleScreen, PlayingScreen

WHITE = (255,255,255)
BLACK = (0,0,0)

class App: # class where the screen is set (most of this class was based on this http://pygametutorials.wikidot.com/tutorials-basic)
    
    def __init__(self,x,y): #constructor setting whether or not the app is running or not, which screen it should display, and the size of the screen displayed
        self.running = True
        self.display = None
        self.size = self.width,self.height = x,y
        """
            gameState = 0 means its on the credits screen
            gameState = 1 means its on the title screen
            gameState = 2 mean its on the play
            gameState = 3 mean its on the point count up
            gameState = 4 mean its on the very end basically just quit the game
        """
        self.gameState = 1
        self.currentScreen = None #which screen should be current
        self.cardSize = (self.size[0] / 10 / self.size[0], self.size[1] / 4 / self.size[1])

    def on_init(self): # initialize all pygame modules and shows a resizable window and makes the application run
        pygame.init()
        pygame.display.set_caption('Crazy Eights')
        self.display = pygame.display.set_mode(self.size, pygame.HWSURFACE | pygame.DOUBLEBUF | pygame.RESIZABLE) #different mode types 
        self.running = True

    def on_loop(self):
        self.display.fill(BLACK)
        for i in self.currentScreen.buttons:
            i.process(self.display)
        

        pygame.display.update()
                    
    def createDeckAndStock(self):
        suits = ["Spades",'Hearts','Clubs','Diamonds']
        ranks = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"]
        deck = []
        for suit in suits: # set the deck of cards
            for rank in ranks:
                deck.append(Card(rank, suit, self))
        random.shuffle(deck)
        stock = deck.pop()
        while stock.rank == '8':
            deck.insert(len(deck)//2,stock)
            stock = deck.pop()
        
        deckPos = (self.size[0]/ 3.5 / self.size[0], self.size[1]/ 3 /self.size[1])
        stockPos = (self.size[0] / 1.5 / self.size[0], self.size[1]/ 3 /self.size[1])
        return Deck(deckPos, self.cardSize, deck, self), Stock(stockPos, self.cardSize, stock, self)


    def run(self):
        if self.on_init() == False: # check if the program is still running
            self.running = False

        #code below is to set up the deck
        deck,stock = self.createDeckAndStock()
        
        #below are some variables for the screens (basically each gamestate has a different screen and each screen contains the actual functionality of the program)
        sizeRatio = 25/self.height
        titleStuff = TitleScreen('Title','arial', self) # set title screen
        titleStuff.addButton("Crazy Eights", ( (self.width/2 - titleStuff.font.size("Crazy Eights")[0]*2/3) / self.width, 0), sizeRatio)
        titleStuff.addButton("Start", ( (self.width/8 - titleStuff.font.size("Start")[0]/2) / self.width, (self.height*5/7 - titleStuff.font.size("Start")[1]/2) / self.height), sizeRatio)
        titleStuff.addButton("Credits", ( (self.width/8 - titleStuff.font.size("Credits")[0]/2) / self.width, (self.height*7/8 - titleStuff.font.size("Credits")[1]/2) / self.height), sizeRatio)
        self.currentScreen = titleStuff

        creditStuff = CreditsScreen('Credits', 'arial', self) # set credits screen
        creditStuff.addButton("Back",(0,0), sizeRatio)
        creditStuff.addButton("Card designs: https://github.com/hanhaechi/playing-cards", (self.width/ 40 /self.width, self.height/ 6 / self.height), sizeRatio)

        playingStuff = PlayingScreen('Game', 'arial', self)
        playingStuff.addToScreen(deck)
        playingStuff.addToScreen(stock)

        playingStuff.addPlayer((0, 1/2), 0,0)
        playingStuff.addAI((1/2, 0), 0, 90)
        playingStuff.addAI((1/2, 1), 0, 180)
        playingStuff.addAI((1, 1/2), 0, 270)

        for i in range(5):
            for player in playingStuff.getPlayers():
                player.addToHand(deck.getCards().pop())

        currentScreens = [creditStuff,titleStuff,playingStuff]
        while(self.running):
            for event in pygame.event.get(): # check events and see if we need to do anything with them
                if event.type == pygame.QUIT: #stops the app from running when pygame quits
                    self.running = False
                if event.type == pygame.VIDEORESIZE: #sets the width,height, and size of the app to the event (what the user changed it to)
                    self.size = self.width,self.height = event.w,event.h
                    
            self.currentScreen = currentScreens[self.gameState]
            self.on_loop()

        pygame.quit()

if __name__ == "__main__" :
    theApp = App(640,400)
    theApp.run()
