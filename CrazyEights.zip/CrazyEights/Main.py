import pygame, Screens, Buttons


WHITE = (255,255,255)
BLACK = (0,0,0)

class Card: # Base class card to lean more on object oriented programming
    def __init__(self, rank, suit):
        self.rank = rank
        self.suit = suit
        self.image = pygame.image.load("./" + suit + "/" + str(rank) + ".jpg").convert()

    def resize_image(self,goalX,goalY):
        self.image = pygame.transform.smoothscale(self.image,(goalX,goalY))

class App: # class where the screen is set (most of this class was based on this http://pygametutorials.wikidot.com/tutorials-basic)
    
    def __init__(self,x,y): #constructor setting whether or not the app is running or not, which screen it should display, and the size of the screen displayed
        self.running = True
        self.display = None
        self.size = self.width,self.height = x,y
        """
            gameState = 0 means its on the credits screen
            gameState = 1 means its on the title screen
            gameState = 2 mean its on the play
            gameState = 3 mean its on the point count up
            gameState = 4 mean its on the very end basically just quit the game
        """
        self.gameState = 1
        self.currentScreen = None #which screen should be current

    def on_init(self): # initialize all pygame modules and shows a resizable window and makes the application run
        pygame.init()
        pygame.display.set_caption('Crazy Eights')
        self.display = pygame.display.set_mode(self.size, pygame.HWSURFACE | pygame.DOUBLEBUF | pygame.RESIZABLE) #different mode types 
        self.running = True

    def on_loop(self):
        self.display.fill(BLACK)
        if(self.gameState == 1): # all title screen stuff
            for i in self.currentScreen.buttons:
                i.process(self.display)
        
        if (self.gameState == 0): # credits screen
            for i in self.currentScreen.buttons:
                i.process(self.display)

        pygame.display.update()
                    
    def run(self):
        if self.on_init() == False: # check if the program is still running
            self.running = False

        """
        set up deck
        suits = ["Spades", "Clubs", "Diamonds", "Hearts"]
        ranks = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"]
        deck = []
        for suit in suits: # set the deck of cards
            for rank in ranks:
                deck.append(Card(rank,suit))
        """
        titleStuff = Screens.TitleScreen('Title',pygame.font.SysFont('arial',25), self) # set title screen
        titleStuff.addButton("Crazy Eights",(self.width/2-self.width/9.5,0))
        titleStuff.addButton("Start", (self.width/9,self.height*6/8))
        titleStuff.addButton("Credits", (self.width/9,self.height*7/8))
        self.currentScreen = titleStuff

        creditStuff = Screens.CreditsScreen('Credits',pygame.font.SysFont('arial',25), self) # set credits screen
        creditStuff.addButton("Back",(0,0))
        creditStuff.addButton("Card designs: Designed by brgfx / Freepik", (self.width/5,self.height/8))

        
        currentScreens = [creditStuff,titleStuff]
        while(self.running):
            for event in pygame.event.get(): # check events and see if we need to do anything with them
                if event.type == pygame.QUIT: #stops the app from running when pygame quits
                    self.running = False
                if event.type == pygame.VIDEORESIZE: #sets the width,height, and size of the app to the event (what the user changed it to)
                    self.size = self.width,self.height = event.w,event.h
                    
            self.currentScreen = currentScreens[self.gameState]
            self.on_loop()

        pygame.quit()

if __name__ == "__main__" :
    theApp = App(640,400)
    theApp.run()

'''
Credits:
    Card designs: Designed by brgfx / Freepik
'''