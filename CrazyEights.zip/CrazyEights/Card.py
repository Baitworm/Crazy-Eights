import pygame
class Card: # Base class card to lean more on object oriented programming
    def __init__(self, rank, suit, app):
        self.rank = rank
        self.suit = suit
        self.image = pygame.image.load("./" + suit + "/" + str(rank) + ".png").convert()
        self.app = app

    def get_Points(self):
        if self.rank == 'Ace':
            return 1
        if self.rank == '8':
            return 50
        if self.rank == 'King' or self.rank == 'Queen' or self.rank == 'Jack':
            return 10
        return self.rank
    
    def equals(self, otherCard):
        return self.rank == otherCard.rank or self.suit == otherCard.suit

    def __str__(self):
        return (str(self.rank) + " " + self.suit)